$(function () {
    // Ensure namespace is set up
    if (typeof xploreHelp === 'undefined') {
        xploreHelp = {};
    }
    xploreHelp = (function () {
        "use strict";
        //Declare Variables

        //Initialization
        function init() {
            //activate expandable menu
            $("#browser").treeview({
                animated: "medium",
                collapsed: true,
                unique: true
            });
            //add a linkContainer wrapper to constrain the width of the links, whose display mode is set to 'inline'
            $("#browser a").wrap("<span class='linkContainer'></span>");

            //add a selected-background container and a pointer arrow element to the LI
            $("#browser li").prepend("<span class='selected-bkgd'></span>").append("<span class='arrow'></span>");


            // JULY2015 request #6
            // set up event listener to link LI clicks to open/close function.
            $("#browser li").on("click", function (e) {
                e.stopPropagation();
                e.preventDefault();
                //debugger
                var _this = $(this),
                    urlPointer = _this.find("a").attr("href");




                //if no collapse/expand needs to happen, then just immediately navigate to the target page
                if (_this.children(".expandable-hitarea, .collapsable-hitarea").length === 0) {

                    // NO SURE WHAT THIS IS BRIAN KOO
                    //navigateTo(urlPointer);
                    // setTimeout( function(){

                    //                        navigateTo(urlPointer);
                    //                    } ,500);

                } else {
                    //set up relevant event listener based on current LI (_this) class
                    // if(_this.hasClass("collapsable")){
                    /*$(".collapsable-hitarea, .expandable-hitarea").off('webkitTransitionEnd transitionend msTransitionEnd oTransitionEnd');
                     $(" > .collapsable-hitarea, > .expandable-hitarea", _this).on('webkitTransitionEnd transitionend msTransitionEnd oTransitionEnd', function() {
                     navigateTo(urlPointer);
                     });*/
                    _this.children(".hitarea").trigger("click", function () {
                        setTimeout( function(){

                                               //Don't attempt to load top-level section page
											   //navigateTo(urlPointer);
                                           } ,500);
                        //navigateTo(urlPointer);
                    });


                }


            });
            
        }

        //Event Handlers

        //Methods
        function highlightCurrentPage(currPage) {
            var selectedBkgdHeight = currPage.parent(".linkContainer").height(),
                parentLI = currPage.parent().parent(),
                currentLIAddlHeight = (parentLI.outerHeight(true) - parentLI.height() + 1 ),  //calculate height of LI's margins, borders, and padding. 1 is added to compensate for the bkgd top value of -1
                currentLIAddlWidth = 0,
                numberOfLvls = currPage.parents('li').length,  //Number of Levels deep the current page is in the hierarchy,
                defaultLiLeftPadding = parseFloat($('#browser > li:first-child').css('padding-left'));
            selectedBkgdHeight += currentLIAddlHeight;  //add the parent LI's margin, border, and padding height to the height of the selected-bkgd element's height

            //do this loop if the current page is not one of the main nav items
            if (numberOfLvls > 1) {
                //subtract one level to exclude the main nav items from the logic
                currentLIAddlWidth = ((numberOfLvls - 1) * defaultLiLeftPadding);
                
            }

            currPage.addClass("selected");

            currPage.parent().siblings(".selected-bkgd").css("height", selectedBkgdHeight);
            currPage.parent().siblings(".selected-bkgd").css("left", (-Math.abs(currentLIAddlWidth)));

            //add 'selected' class to its surrounding LI as well for CSS styling purposes
            parentLI.addClass("selected");
            return;
        }

        function writePageTitle(el) {
            document.title = el;
        }

        function resetCallback() {
            $("body").removeClass("notransition"); //reactivate CSS3 transitions while page is reset
        }

        function navigateTo(destinationUrl) {
            window.location.href = destinationUrl;
        }

        function swapVideo(code) {
            $('iframe').attr('src', 'http://www.youtube.com/embed/' + code + '?enablejsapi=1&wmode=opaque');
        }

        function searchFocus() {
            $('#txtSearchTerm').focus();
        }

        function writeBreadcrumb(obj) {
            $('#browser a').removeClass("left-nav-breadcrumb-trail");  //prepare to write a new breadcrumb trail by removing the previous trail
            var isTopLevel = false,
            //$parentULs = $(obj.parents("ul")),
                path = obj.parents("ul")
                    .prev(".linkContainer").find("a").addClass("left-nav-breadcrumb-trail")
                    .map(function () {

                        //create each list item
                        //old breadcrumb syntax --  var fullUrl = "<li><a href='" + $(this).attr('') + "'>" + $(this).text() + "</a></li>";
                        var fullUrl = '<li><a href="/resources">Resources and Help</a></li>';
						return (fullUrl);

                    }).get();

            if (path.length === 0) {
                isTopLevel = true;
            }

            path = path.join("");

            //add current page to the breadcrumb unless you're at the top level of the hierarchy
            ////JULY2015 request #5 - per client request, the topmost level of the breadcrumb is not to be part of the breadcrumb trail
            if (!isTopLevel) {
                path += "<li>" + obj.text() + "</li>";
            }

            $("#breadcrumb ul").html(path);
        }

        function resetPage(callback) {
            
            $("body").addClass("notransition"); //temporarily deactivate CSS3 transitions while page is reset


            //create a string which is the URL minus the domain and http://
            var url = document.location.href;

            var hasSubsectionRegex = /([^#]*)#([^#]*)#.*/;
            if(hasSubsectionRegex.test(url)){
              url = url.replace(hasSubsectionRegex, "$1#$2");
            }

            url = url.replace('http://', '');
            //get rid of the trailing slash /
            var url_parts = url.replace(/\/\s*$/, '').split('/');

            //create a copy of the array of URL pieces
            var url_parts_copy = url_parts.slice();

            //iterate through the array and remove unwanted pieces from the copy
            $.each(url_parts, function () {
                //alert(this);
                if (this == "#") {
                    return false;
                }
                else {
                    url_parts_copy.shift();
                }
            });
            //then set original array = the copy array
            url_parts = url_parts_copy.slice();


            var currURL = url_parts.join('/');

            if (currURL == "" || currURL == "#") {
                ///this takes care of the condition where the URL could be "#" or "" --both valid URLs that user can type into browser--but they
                // would cause an error in the breadcrumb handler and the active page highlighting since there is no matching URL in the main navigation tree
                currURL = "/resources";
            }


            //check whether this string matches any of the menu item URLs.
            //If match, traverse the NAV upwards from this point, and rebuild the breadcrumb with this information

            var currPage;
            currPage = $('#browser').find('a[href="' + currURL + '"]'); //points to a jquery A object

            writeBreadcrumb(currPage);

            //clear the nav A and LI highlighting so that only the A (and its surrounding LI) associated with page you're on will be highlighted
            $("#browser a, #browser li").each(function () {
                $(this).removeClass("selected");

            });

            //force the menu open to display the page user is navigating to
            var parentUL = currPage.parents("ul");
            parentUL.each(function () {
                $(this).css('display', 'block');
            });

            //update the menu classes to reflect the current state of the nav (open/closed)
            $("#browser .expandable, #browser .collapsable").each(function () {

                $(this).removeClass('collapsable expandable'); //remove all classes as we prepare to re-add them based on open/closed status

                if ($(this).children("ul").is(":visible")) {
                    $(this).addClass('collapsable');
                    $(this).children(".hitarea").each(function () {

                        $(this).removeClass("expandable-hitarea collapsable-hitarea");
                        $(this).addClass("collapsable-hitarea");

                    });
                } else {
                    $(this).addClass('expandable');
                    $(this).children(".hitarea").removeClass("expandable-hitarea collapsable-hitarea").addClass("expandable-hitarea");
                }

            });
            // console.log($(this).has("ul").length > 0);
            //if (this.child('ul')){
            //    
            //}


            //highlight the NAV item that the user has clicked
            highlightCurrentPage(currPage);

            //update the browser title to match new page
            writePageTitle(currPage.text());


            //trigger the callback function
            if (typeof callback === 'function') {
                callback();
            }

        }



        init();

        //Public Interface
        return {
            swapVideo: swapVideo,
            resetPage: resetPage,
            searchFocus: searchFocus
        };

    }(xploreHelp));
});



function swapVideo(code) {
    $('iframe').attr('src', 'http://www.youtube.com/embed/' + code + '?enablejsapi=1&wmode=opaque');
}


function urlRedirect(oldLink, newLink){

    var url = document.location.href;

    if(url === oldLink){
	    location.replace(newLink);				
	}

    //Fix %23 encoding, change to "#"
    if(url.match(oldLink)){
        var hashEncodeLink = url.replace(oldLink, newLink);
	    location.replace(hashEncodeLink);				
	}




}

//Redirects

//IE browser support redirect
urlRedirect("http://ieeexplore.ieee.org/Xplorehelp/resources/techLegalInfo/browserSupport", "http://ieeexplore.ieee.org/Xplorehelp/overview-of-ieee-xplore/web-support");

//Experiencing Multimedia redirect
urlRedirect("http://ieeexplore.ieee.org/Xplorehelp/workingWithDocuments/experiencingMultimedia", "http://ieeexplore.ieee.org/Xplorehelp/ieee-xplore-training/working-with-documents#experiencing-multimedia");

//ODI Conformance
urlRedirect("http://ieeexplore.ieee.org/Xplorehelp/tools/toolsForAdministratorsAndLibrarians/discoveryServices/openDiscoveryInitiativeConformance", "http://ieeexplore.ieee.org/Xplorehelp/administrators-and-librarians/open-discovery-initiative-conformance");

//Title Lists
urlRedirect("http://ieeexplore.ieee.org/Xplorehelp/tools/toolsForAllUsers/titleLists", "http://ieeexplore.ieee.org/Xplorehelp/administrators-and-librarians/title-lists");

//Discovery Services
urlRedirect("http://ieeexplore.ieee.org/Xplorehelp/tools/toolsForAdministratorsAndLibrarians/discoveryServices", "http://ieeexplore.ieee.org/Xplorehelp/administrators-and-librarians/discovery-services");

urlRedirect("http://xploreqa.ieee.org/Xplorehelp/about-ieee-xplore","http://ieeexplore.ieee.org/Xplorehelp/resources");

urlRedirect("http://ieeexplore.ieee.org/Xplorehelp/searchingIeeeXplore/tipsForEffectiveUseOfSearch","http://ieeexplore.ieee.org/Xplorehelp/searching-ieee-xplore/search-tips");

urlRedirect("http://ieeexplore.ieee.org/Xplorehelp/ieee-xplore-training/working-with-documents#interactive-html","http://ieeexplore.ieee.org/Xplorehelp/ieee-xplore-training/working-with-documents");

urlRedirect("http://ieeexplore.ieee.org/Xplorehelp/administrators-and-librarians/ebooks-marc-records","http://ieeexplore.ieee.org/Xplorehelp/administrators-and-librarians/marc-records");





var hastagEncode = /([^%]*)%23([^.]*)/;

urlRedirect(hastagEncode,"$1#$2");